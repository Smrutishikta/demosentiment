from flask import Flask, render_template, url_for, redirect, request, flash, send_file
#from werkzeug.utils import secure_filename
import os
from secrets import token_hex
from model.predict import predict, initialise


def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() == "csv"


app = Flask(__name__)
upfolder = './model'
app.config['UPLOAD_FOLDER'] = upfolder

# app.config["SECRET_KEY"] = "b6c6a2626338ec390574c78f8ee39d66"
app.config["SECRET_KEY"] = os.environ.get("SECRET_KEY", token_hex(16))


@app.route('/', methods=['GET', 'POST'])
@app.route('/upload', methods=['GET', 'POST'])
def upload():
    if request.method == 'POST':
        if 'file' not in request.files:
            flash('No file found', 'info')
            return redirect(request.url)
        file = request.files['file']
        if file.filename == '':
            flash('No file selected for uploading', 'info')
            return redirect(request.url)
        if file and allowed_file(file.filename):
            val = predict(file, model, offensive_words,upfolder)
            if val:
                flash(val, 'info')
                return redirect(request.url)
            else:
                flash('File successfully uploaded', 'success')
                return redirect(url_for('results'))
        else:
            flash('Only CSV files are allowed', 'info')
            return redirect(request.url)
    else:
        return render_template('upload.html', title='Upload')


@app.route('/results')
def results():
    return send_file(os.path.join(upfolder, 'result.csv'),
                     mimetype='text/csv',
                     attachment_filename='result.csv',
                     as_attachment=True)


@app.errorhandler(Exception)
def handle_error(e):
    return render_template("errorpage.html")


if __name__ == '__main__':
    model, offensive_words = initialise(upfolder)
    app.run(port=5000, debug=True)
