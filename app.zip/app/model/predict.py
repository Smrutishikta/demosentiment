import pandas as pd
import numpy as np
import os
import re
from flair.models import TextClassifier
from flair.data import Sentence


def get_offensive_corpus(path):
    offensive_words = []
    with open(path, 'r', encoding='utf-8') as f:
        for i in f.readlines():
            i = i.strip()
            i = i.lower()
            i = re.sub(r'[.\-_?!,;:#]', "", i)
            offensive_words.append(i)
            s = re.sub(r'(.)\1{2,}', r'\1', i)
            offensive_words.append(s)
    offensive_words = list(filter(lambda x: len(x) > 0, offensive_words))
    offensive_words = set(offensive_words)
    return offensive_words


def initialise(path):
    offensive_path = os.path.join(path, "word_corpus.csv")
    offensive_words = get_offensive_corpus(offensive_path)

    model = TextClassifier.load('en-sentiment')
    model = " "
    return model, offensive_words


def preprocess(text):
    text = text.lower()
    text = re.sub(r'[.\-_?!,;:]', "", text)
    text = text.strip()
    text = re.sub(r'(.)\1{2,}', r'\1', text)
    return text


def check_offense(text, offensive_words, model):
    sentence = Sentence(text)
    model.predict(sentence)
    labels = sentence.labels
    if 'NEGATIVE' in str(labels[0]):
        text = preprocess(text)
        intersect = set(text.split()) & offensive_words
        if intersect:
            return "offensive"
        else:
            return " "
    else:
        return " "



def predict(file, model, offensive_words,upfolder):
    try:
        data = pd.read_csv(file)
        data['offensive'] = data['text'].apply(
            lambda x: check_offense(x, offensive_words, model))
        data.to_csv(os.path.join(upfolder,"result.csv"), index=False)
        return None
    except Exception:
        return "Error Found"
